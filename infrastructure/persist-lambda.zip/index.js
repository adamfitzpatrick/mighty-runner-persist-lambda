exports.handler = require('./lib/persist-lambda')
